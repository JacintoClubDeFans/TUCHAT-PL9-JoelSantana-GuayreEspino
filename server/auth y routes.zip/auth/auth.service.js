import { gobDb } from "../db/gobcan.db.js";
import { appDb } from "../db/app.db.js";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import env from "../config/env.js";

const sha256 = (input) => crypto.createHash("sha256").update(input).digest("hex");

export const loginConCredenciales = async ({ identificador, password }) => {
  // Buscar persona en DB Externa
  const { rows: personas } = await gobDb.query(
    `SELECT p.*, ug.id_usuario_externo, ug.tipo, cred.salt, cred.password_sha256_hex, c.codigo_centro
     FROM externo.personas p
     JOIN externo.usuarios_gobierno ug ON ug.id_persona = p.id_persona
     JOIN externo.credenciales_acceso cred ON cred.id_usuario_externo = ug.id_usuario_externo
     JOIN externo.centros c ON c.id_centro = ug.id_centro
     WHERE (p.dni = $1 OR p.cial = $1) 
       AND ug.activo = true AND p.activo = true`,
    [identificador]
  );

  if (!personas.length) throw new Error("INVALID_CREDENTIALS");
  const extUser = personas[0];

  // Verificar Password
  const hash = sha256(extUser.salt + password);
  if (hash !== extUser.password_sha256_hex) throw new Error("INVALID_CREDENTIALS");

  // Obtener ID de Rol local (Seguridad)
  // Asumimos que en seguridad.roles: 1 = PROFESOR, 2 = ALUMNO
  const { rows: roles } = await appDb.query(
    "SELECT id_rol FROM seguridad.roles WHERE nombre = $1",
    [extUser.tipo] // 'PROFESOR' o 'ALUMNO'
  );
  const idRol = roles[0]?.id_rol || 2; // Default a Alumno si no se encuentra

  // Sync en seguridad.usuarios_app (UPSERT)
  const { rows: usuariosApp } = await appDb.query(
    `INSERT INTO seguridad.usuarios_app (
      id_usuario_externo, dni, cial, id_rol, nombre, apellidos, tipo_externo, codigo_centro, activo
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
    ON CONFLICT (id_usuario_externo) DO UPDATE SET
      nombre = EXCLUDED.nombre,
      apellidos = EXCLUDED.apellidos,
      id_rol = EXCLUDED.id_rol,
      codigo_centro = EXCLUDED.codigo_centro,
      updated_at = NOW()
    RETURNING *`,
    [extUser.id_usuario_externo, extUser.dni, extUser.cial, idRol, extUser.nombre, extUser.apellidos, extUser.tipo, extUser.codigo_centro]
  );
  const localUser = usuariosApp[0];

  // Actualizar seguridad.sync_estado_usuario 
  await appDb.query(
    `INSERT INTO seguridad.sync_estado_usuario (id_usuario_app, ultimo_sync, ultimo_sync_ok)
     VALUES ($1, NOW(), true)
     ON CONFLICT (id_usuario_app) DO UPDATE SET
     ultimo_sync = NOW(), ultimo_sync_ok = true, detalle_ultimo_error = null`,
    [localUser.id_usuario_app]
  );

  // Generar JWT
  const token = jwt.sign(
    { sub: localUser.id_usuario_app, rol: idRol },
    env.JWT_SECRET,
    { expiresIn: "7d" }
  );

  return {
    token,
    usuario: {
      id: localUser.id_usuario_app,
      nombre: localUser.nombre,
      tipo: localUser.tipo_externo
    }
  };
};