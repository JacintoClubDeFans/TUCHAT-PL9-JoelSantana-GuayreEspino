import { loginConCredenciales } from "./auth.service.js";

export const login = async (req, res) => {
  try {
    const { identificador, password } = req.body;

    // Validación básica de entrada
    if (!identificador || !password) {
      return res.status(400).json({ 
        ok: false, 
        error: "MISSING_FIELDS",
        msg: "DNI/CIAL y contraseña son obligatorios" 
      });
    }

    // Llamada al servicio (donde ocurre el Sync y el acceso a seguridad.usuarios_app)
    const result = await loginConCredenciales({ identificador, password });

    return res.json({
      ok: true,
      token: result.token,
      usuario: result.usuario
    });

  } catch (err) {
    console.error("[Login Error]:", err.message);

    if (err.message === "INVALID_CREDENTIALS") {
      return res.status(401).json({ 
        ok: false, 
        error: "INVALID_CREDENTIALS",
        msg: "Usuario o contraseña incorrectos" 
      });
    }

    // Si el error es de base de datos o de código, devolvemos un 500
    return res.status(500).json({ 
      ok: false, 
      error: "SERVER_ERROR",
      msg: "Error interno en el servidor de TuCHAT" 
    });
  }
};