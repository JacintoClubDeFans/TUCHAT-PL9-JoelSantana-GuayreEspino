import jwt from "jsonwebtoken";
import { appDb } from "../db/app.db.js"; 
import env from "../config/env.js";

export const requireAuth = async (req, res, next) => {
  const header = req.headers.authorization;

  // Verificar que el header existe y tiene el formato Bearer
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ ok: false, error: "NO_TOKEN" });
  }

  const token = header.split(" ")[1];

  try {
    // Verificar el JWT
    const payload = jwt.verify(token, env.JWT_SECRET);

    // Buscar al usuario en el esquema 
    const { rows } = await appDb.query(
      `SELECT id_usuario_app, dni, id_rol, nombre, tipo_externo, activo 
       FROM seguridad.usuarios_app 
       WHERE id_usuario_app = $1`,
      [payload.sub]
    );

    // Verificar si el usuario existe y está activo
    if (!rows.length) {
      return res.status(401).json({ ok: false, error: "USER_NOT_FOUND" });
    }

    if (!rows[0].activo) {
      return res.status(403).json({ ok: false, error: "USER_INACTIVE" });
    }

    // Inyectar el usuario en la request para que los controladores lo usen
    req.currentUser = rows[0];
    
    next();
  } catch (err) {
    // Si el token expiró o es inválido
    return res.status(401).json({ ok: false, error: "INVALID_TOKEN" });
  }
};